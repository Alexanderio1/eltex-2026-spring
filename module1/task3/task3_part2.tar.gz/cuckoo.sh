#!/usr/bin/env bash
set -u

RUNDIR=/tmp/run
REQ_FIFO="$RUNDIR/cuckoo.pid"
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
LOG="$BASE_DIR/cuckoo.log"

ts() {
    date '+%F %T'
}

log_line() {
    printf '%s %s\n' "$(ts)" "$1" >> "$LOG"
}

shutdown() {
    log_line "Shutdown!"
    rm -f "$REQ_FIFO"
    exit 0
}

mkdir -p "$RUNDIR"
rm -f "$REQ_FIFO"
mkfifo "$REQ_FIFO"

trap shutdown TERM

log_line "Startup!"

while true; do
    if IFS= read -r line < "$REQ_FIFO"; then
        if [[ "$line" =~ ^([^[]+)\[([0-9]+)\]:[[:space:]]how[[:space:]]much[[:space:]]time[[:space:]]do[[:space:]]I[[:space:]]have\?$ ]]; then
            name="${BASH_REMATCH[1]}"
            pid="${BASH_REMATCH[2]}"
            n=$((RANDOM % 9 + 2))
            log_line "${name}[${pid}] ${n}"

            reply_fifo="$RUNDIR/${pid}.reply"
            if [[ -p "$reply_fifo" ]]; then
                printf '%s\n' "$n" > "$reply_fifo"
            fi
        fi
    fi
done
