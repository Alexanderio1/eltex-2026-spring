#!/usr/bin/env bash
set -u

SCRIPT_NAME="$(basename "$0")"
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$BASE_DIR"

LOG="$BASE_DIR/report_${SCRIPT_NAME}.log"
REQ_FIFO="/tmp/run/cuckoo.pid"
PID="$$"

ts() {
    date '+%F %T'
}

if [[ "$SCRIPT_NAME" == "template_task.sh" ]]; then
    echo "я бригадир, сам не работаю"
    exit 0
fi

printf '%s [%s] Скрипт запущен\n' "$(ts)" "$PID" >> "$LOG"

REPLY_FIFO="/tmp/run/${PID}.reply"
rm -f "$REPLY_FIFO"
mkfifo "$REPLY_FIFO"

printf '%s[%s]: how much time do I have?\n' "$SCRIPT_NAME" "$PID" > "$REQ_FIFO"
IFS= read -r N < "$REPLY_FIFO"
rm -f "$REPLY_FIFO"

sleep "$N"

printf '%s [%s] Скрипт завершился, работал %s секунд.\n' "$(ts)" "$PID" "$N" >> "$LOG"
