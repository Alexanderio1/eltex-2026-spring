#!/usr/bin/env bash
set -u

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
CONFIG="$BASE_DIR/observer.conf"
LOG="$BASE_DIR/observer.log"

ts() {
    date '+%F %T'
}

is_running() {
    local target="$1"
    local f cmdline

    for f in /proc/[0-9]*/cmdline; do
        [[ -r "$f" ]] || continue
        cmdline="$(tr '\0' ' ' < "$f" 2>/dev/null || true)"
        [[ "$cmdline" == *"$target"* ]] && return 0
    done

    return 1
}

while IFS= read -r script; do
    [[ -z "$script" || "$script" =~ ^# ]] && continue

    if [[ ! -x "$script" ]]; then
        printf '%s %s missing_or_not_executable\n' "$(ts)" "$script" >> "$LOG"
        continue
    fi

    if ! is_running "$script"; then
        nohup "$script" >/dev/null 2>&1 &
        printf '%s restarted %s\n' "$(ts)" "$script" >> "$LOG"
    fi
done < "$CONFIG"
